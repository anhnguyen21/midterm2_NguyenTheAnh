
    <h1><?php echo e($detail['title']); ?></h1>
    <p><?php echo e($detail['body']); ?></p>
    <p>Thank You</p>
<?php /**PATH C:\xampp\htdocs\Source\SourceRs\resources\views/testEmail.blade.php ENDPATH**/ ?>