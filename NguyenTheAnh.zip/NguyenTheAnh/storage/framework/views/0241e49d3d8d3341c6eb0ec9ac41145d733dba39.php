<?php $__env->startSection('content'); ?>

<div class="inner-header">
    <div class="container">
        <div class="pull-left">
        <h6 class="inner-title"><?php echo e($sanpham->name); ?></h6>
        </div>
        <div class="pull-right">
            <div class="beta-breadcrumb font-large">
                <a href="index.html">Home</a> / <span>Product</span>
            </div>
        </div>
        <div class="clearfix"></div>
    </div>
</div>

<div class="container">
    <div id="content">
        <div class="row">
            <div class="col-sm-9">

                <div class="row">
                    <div class="col-sm-4">
                    <img src="public/source/image/product/<?php echo e($sanpham->image); ?>" alt="">
                    </div>
                    <div class="col-sm-8">
                        <div class="single-item-body">
                        <p class="single-item-title"><?php echo e($sanpham->name); ?></p>
                            <p class="single-item-price">
                            <span><?php echo e($sanpham->unit_price); ?> đ</span>
                            </p>
                        </div>

                        <div class="clearfix"></div>
                        <div class="space20">&nbsp;</div>

                        <div class="single-item-desc">
                        <p><?php echo e($sanpham->description); ?></p>
                        </div>
                        <div class="space20">&nbsp;</div>

                        <div class="single-item-options">
                            <input type="number">
                            <a class="add-to-cart" href="#"><i class="fa fa-shopping-cart"></i></a>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>

                <div class="space40">&nbsp;</div>
                <div class="woocommerce-tabs">
                    <ul class="tabs">
                        <li><a href="#tab-description">Description</a></li>
                        <li><a href="#tab-reviews">Reviews (0)</a></li>
                    </ul>

                    <div class="panel" id="tab-description">
                        <p><?php echo e($sanpham->description); ?></p>
                    </div>
                    <div class="panel" id="tab-reviews">
                        <p>No Reviews</p>
                    </div>
                </div>
                <div class="space50">&nbsp;</div>
                <div class="beta-products-list">
                    <h4>Related Products</h4>

                    <div class="row">
                        <?php $__currentLoopData = $sp_tuongtu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-4">
                            <div class="single-item">
                                <?php if($item->promotion>0): ?>
                                    <div class="ribbon-wrapper"><div class="ribbon sale">Sale</div></div>
                                <?php endif; ?>


                                <div class="single-item-header">
                                    <a href="#"><img src="public/source/image/product/<?php echo e($item->image); ?>" alt=""></a>
                                </div>
                                <div class="single-item-body">
                                <p class="single-item-title"><?php echo e($item->name); ?></p>
                                    <p class="single-item-price">
                                        <?php if($item->promotion>0): ?>
                                            <span class="flash-del"><?php echo e($item->unit_price); ?></span>
                                            <span class="flash-sale"><?php echo e($item->promotion_price); ?></span>
                                        <?php else: ?>
                                            <span><?php echo e($item->unit_price); ?></span>
                                        <?php endif; ?>


                                    </p>
                                </div>
                                <div class="single-item-caption">
                                    <a class="add-to-cart pull-left" href="#"><i class="fa fa-shopping-cart"></i></a>
                                    <a class="beta-btn primary" href="#">Details <i class="fa fa-chevron-right"></i></a>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div> <!-- .beta-products-list -->
            </div>
            <div class="col-sm-3 aside">
                <div class="widget">
                    <h3 class="widget-title">Best Sellers</h3>
                    <div class="widget-body">
                        <div class="beta-sales beta-lists">
                            <?php $__currentLoopData = $sp_banchay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="media beta-sales-item">
                                <a class="pull-left" href="#"><img src="public/source/image/product/<?php echo e($item->image); ?>" alt=""></a>
                                <div class="media-body">
                                   <?php echo e($item->name); ?>

                                <span class="beta-sales-price"><?php echo e($item->unit_price); ?></span>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>
                </div> <!-- best sellers widget -->
                <div class="widget">
                    <h3 class="widget-title">New Products</h3>
                    <div class="widget-body">
                        <div class="beta-sales beta-lists">
                            <?php $__currentLoopData = $sp_new; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="media beta-sales-item">
                                <a class="pull-left" href="#"><img src="public/source/image/product/<?php echo e($item->image); ?>" alt=""></a>
                                <div class="media-body">
                                   <?php echo e($item->name); ?>

                                <span class="beta-sales-price"><?php echo e($item->unit_price); ?></span>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>
                </div> <!-- best sellers widget -->
            </div>
        </div>
    </div> <!-- #content -->
</div> <!-- .container -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SourceRs\resources\views/page/chi_tiet.blade.php ENDPATH**/ ?>