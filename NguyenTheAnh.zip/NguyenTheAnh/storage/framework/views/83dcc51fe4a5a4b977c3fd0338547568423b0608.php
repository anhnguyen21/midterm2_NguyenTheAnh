<?php $__env->startSection('content'); ?>
<div class="container">
    <div id="content" class="space-top-none">
        <div class="main-content">
            <div class="space60">&nbsp;</div>
            <div class="row">
                <div class="row">
                    <?php $__currentLoopData = $proSear; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-3">
                        <div class="single-item">
                            <div class="single-item-header">
                            <a href="<?php echo e(route('chitietsanpham',$item->id)); ?>"><img src="public/source/image/product/<?php echo e($item->image); ?>" alt=""></a>
                            </div>
                            <div class="single-item-body text-center">
                                <p class="single-item-title"><?php echo e($item->name); ?></p>
                                <p class="single-item-price">
                                    <span><?php echo e($item->unit_price); ?></span>
                                </p>
                            </div>
                            <div class="single-item-caption text-center">
                                <a class="add-to-cart" href="<?php echo e(route('themgiohang',$item->id)); ?>"><i class="fa fa-shopping-cart"></i></a>
                                <a class="beta-btn primary" href="<?php echo e(route('chitietsanpham',$item->id)); ?>">Details <i class="fa fa-chevron-right"></i></a>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SourceRs\resources\views/page/search.blade.php ENDPATH**/ ?>