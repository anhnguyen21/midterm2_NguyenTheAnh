
    <h1>{{$detail['title']}}</h1>
    <p>{{$detail['body']}}</p>
    <p>Thank You</p>
